/*
	select all flight history for user
*/
<?php

?>