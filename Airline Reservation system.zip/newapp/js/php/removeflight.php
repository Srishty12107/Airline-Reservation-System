/*
	remove flight 
*/
<?php

?>