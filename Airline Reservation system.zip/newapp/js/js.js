$(document).ready(function() {
	alert("stuff will happen");
});
