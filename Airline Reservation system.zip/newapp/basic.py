from flask import Flask, render_template,request
app = Flask(__name__)
from mysql.connector import errorcode
from flask.views import MethodView
#from app import api, db
#from flask_restful import abort
#from .forms import LoginForm, AddForm, RegForm
##import password

import mysql.connector
##print password.life
cnx = mysql.connector.connect(user='root', password='sudipmittal',
                              host='127.0.0.1', port='3306',database='DBProj')
@app.route('/index')
def main():
         return render_template('index.html')
      
##@app.route('/index/oneway',methods=['GET','POST'])
##def search():
##   if request.method == 'POST':
##      return render_template('oneway.html')
##   
##@app.route('/index/roundtrip',methods=['GET','POST'])
##def search():
##   if request.method == 'POST':
##      return render_template('roundtrip.html')   
   
##main_view_func = search.as_view('search')
##app.add_url_rule('/',
##             view_func=main_view_func,
##             methods=["POST"])
##
##app.add_url_rule('/oneway/',
##             view_func=main_view_func,
##             methods=["GET"])
@app.route('/index/showSignUp',methods=['GET','POST'])
def showSignUp():
   if request.method == 'POST':
      print "enter"
      return render_template('showSignup.html')
       #return redirect(url_for('main'))
@app.route('/index/showSignUp/index2',methods=['GET','POST'])
def index2():
   if request.method=='POST':
      return render_template('index2.html')
@app.route('/index/showSignUp/index2/index3',methods=['GET','POST'])
def index3():
   if request.method=='POST':
      return render_template('index3.html')

@app.route('/index/showSignUp/index2/index3/index4',methods=['GET','POST'])
def index4():
   if request.method=='POST':
      return render_template('index4.html')
   
@app.route('/index/showSignUp/index2/index3/index5',methods=['GET','POST'])
def index5():
   if request.method=='POST':
      return render_template('index5.html')   
   
   
# read the posted values from the UI
##    _name = request.form['inputName']
##    _email = request.form['inputEmail']
##    _password = request.form['inputPassword']
## 
##    # validate the received values
##    if _name and _email and _password:
##        return json.dumps({'html':'<span>All fields good !!</span>'})
##    else:
##        return json.dumps({'html':'<span>Enter the required fields</span>'})
##    if request.method == 'POST':
##       return redirect(url_for('main'))
   
@app.route('/index/about',methods=['GET','POST'])
def about():
   if(request.method == 'POST'):
      return render_template('about.html')
   
@app.route('/index/showSignUp/index2/index3/index4/search1',methods=['GET','POST'])
def search1():
   if request.method == 'POST':
      return render_template('cart.html')
   
@app.route('/index/showSignUp/index2/index3/index5/search2',methods=['GET','POST'])
def search2():
   if request.method == 'POST':
      return render_template('cart1.html')

   
   
@app.route('/index/showSignUp/index2/index3/index4/search1/booked1',methods=['GET','POST'])
def booked1():
   if request.method == 'POST':
      print "enter"
      return render_template('checkout.html')
   
@app.route('/index/showSignUp/index2/index3/index5/search2/booked2',methods=['GET','POST'])
def booked2():
   if request.method == 'POST':
      return render_template('checkout1.html')
   
@app.route('/index/showSignUp/index2/index3/index4/search1/booked1/cancel',methods=['GET','POST'])
def cancel1():
   if request.method == 'POST':
      return render_template('cancel.html')
   
@app.route('/index/showSignUp/index2/index3/index5/search2/booked2/cancel1',methods=['GET','POST'])
def cancel2():
   if request.method == 'POST':
      return render_template('cancel.html')
      
   
##@app.route('/index/search/booked/removed',methods=['GET','POST'])
##def booked():
##   if request.method == 'POST':
##      return render_template('cancel.html')
##   
   
   
#@app.route('/')
##def main():
####  if form.validate_on_submit():
####    if 'search' in request.form:
####       return 'welcome'
##  return render_template('index.html')
##def contact():
##    if request.method == 'POST':
##        if request.form['submit'] == 'Do Something':
##            pass # do something
##        elif request.form['submit'] == 'Do Something Else':
##            pass # do something else
##        else:
##            pass # unknown
##    elif request.method == 'GET':
##        return render_template('contact.html', form=form)

##@app.route('/search',methods=['GET','POST'])
####def signUp():
## 
##    # read the posted values from the UI
####    _name = request.form['Origin']
####    _email = request.form['Destination']
##    results='srishty'
##@app.route('/b')
##def b():
##    my_var = request.args.get('my_var', None)    
####def main():
####    return render_template('index.html')


if __name__ == "__main__":
    app.run(host='127.0.0.1',port=76)    

    
